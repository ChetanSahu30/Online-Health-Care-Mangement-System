import java.io.*;
public class Mostpatientsvisited
{
//String doctorname ;
String doctorspecialty;
String count;


public  Mostpatientsvisited(String doctorspecialty,String count)
{
	
	//this.doctorname = doctorname ;
	this.doctorspecialty = doctorspecialty;
    this.count = count;
}
/*

public String getDoctorname(){
 return doctorname;
}*/

public String getDoctorspecialty () {
 return doctorspecialty;
}

public String getCount () {
 return count;
}
}